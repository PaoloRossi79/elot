<?php

$db = array(
        'connectionString' => 'mysql:host=localhost;dbname=my_paolorossi79',
        'emulatePrepare' => true,
        'username' => 'paolorossi79',
        'password' => 'rsspla79',
        'charset' => 'utf8',
);

?>
