<?php
/* @var $this SiteController */
/* @var $error array */
?>

<h2>Error Non sei il proprietario</h2>
