<?php
return array (
	'Email' => 'Email',
	'Nickname' => 'Nome de usuário',
	'Password' => 'Senha',
	'Sorry, but password is incorrect' => 'Pedimos desculpa, mas a senha está incorreta',
	'Submit' => 'Enviar',
	'This {attribute} is taken by another user. If this is your account, enter password in field below or change {attribute} and leave password blank.' => 'Este {attribute} já está a ser usado por outro usuário. Se esta é a sua conta, introduza a senha no campo abaixo, ou altere o {attribute} e deixe a senha em branco',
	'Please specify your nickname and email to end with registration.' => 'Por favor especifique o seu nome de usuário e email para terminar o processo de registo.',
	'Please specify your nickname to end with registration.' => 'Por favor especifique o seu nome de usuário para terminar o processo de registo.',
	'Please specify your email to end with registration.' => 'Por favor especifique o seu email para terminar o processo de registo.',
	'Sorry, but your account' => 'Pedimos desculpa, mas a sua conta',
	'must be activated! Check your email for details!' => 'necessita ser ativada antes de entrar. Por favor consulte o seu email para mais informações.',
	'is banned!' => 'foi bloqueada.',
	'Return to main page' => 'Voltar à página de início',
	'Return to login page' => 'Voltar à página de entrada',
);
