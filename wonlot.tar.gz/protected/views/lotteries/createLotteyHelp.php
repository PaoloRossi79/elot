<div class="panel panel-default bootstrap-widget-table">
    <div class="panel-heading">
      <h3 class="panel-title"><?php echo Yii::t('wonlot','Help');?></h3>
    </div>
    <div class="panel-body">
        PROCEDERE ALLA CREAZIONE DI UNA LOTTERIA
Ti ricordiamo che hai diritto a vendere solo beni di tua proprietà e realmente esistenti.
Una volta registrato accedi nell’apposita area MY LOTTERY e provvedi a compilare i campi relativi al bene o servizio.
1- Inserisci i dati tecnici del bene (prezzo, descrizione, stato, condizioni di spedizione/consegna)
2- Decidi il valore in wM da attribuire al singolo wT.
3- decidi quanto tempo tenere i tuoi wT in vendita. 
La classica lotteria dove viene definita una data di inizio e una di estrazione. L’estrazione del wT vincente avviene alla data prefissata indipendentemente dal numero di wT acquistati. 
Puoi inserire un tetto massimo in wT raggiunto il quale l’estrazione verrà anticipata prima dello scadere. Verrà resa pubblica, nella tua lotteria, la probabilità teorica di vincita relativa al tetto indicato.
Puoi comunque annullare la lotteria fino alle 24 ore precedenti l’estrazione. In automatico gli wT verranno rimborsati ai giocatori.
In questo arco di tempo è comunque possibile acquistare gli wT per partecipare all’estrazione. Se la lotteria viene annullata per “acquisto diretto” gli wT vengono rimborsati automaticamente.
    </div>
    <div class="panel-footer">
    </div>
</div>