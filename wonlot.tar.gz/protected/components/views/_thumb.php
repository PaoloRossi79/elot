<li class="span3">
	<a href="#" class="thumbnail" rel="tooltip" data-title="Tooltip">
		<img src="<?php echo bu('images/placeholder260x180.gif');?>" alt="">
	</a>
</li>