# This is my README

THUMBS

            'smallThumb' => array(
                'max_width' => 50,
                'max_height' => 100,
            ),
            'mediumThumb' => array(
                'max_width' => 100,
                'max_height' => 200,
            ),
            'mediumSquaredThumb' => array(
                'max_width' => 200,
                'max_height' => 200,
                'crop_img' => true,
                'jpeg_quality' => 100,
            ),
            'largeThumb' => array(
                'max_width' => 300,
                'max_height' => 600,
            ),
            'boxThumb' => array(
                'max_width' => 200,
            ),
            'galleryBigThumb' => array(
                'max_width' => 700,
                'max_height' => 2000,
                'crop_img' => true,
                'jpeg_quality' => 100,
            ),
            'gallerySmallThumb' => array(
                'max_width' => 200,
                'max_height' => 150,
                'crop_img' => true,
                'jpeg_quality' => 100,
            ),