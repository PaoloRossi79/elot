<?php

$db = array(
        'connectionString' => 'mysql:host=localhost;dbname=elot',
        'emulatePrepare' => true,
        'username' => 'cupu',
        'password' => 'Cupuppo!!Reader',
        'charset' => 'utf8',
);

?>
