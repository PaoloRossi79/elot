ALTER TABLE `elot`.`lotteries` 
ADD COLUMN `ticket_sold_value` INT(10) NULL DEFAULT 0 AFTER `ticket_value`;


