<?php
/**
 * @var HOAuthAction $this
 * @var HUserInfoForm $form
 */

echo $form->form;
