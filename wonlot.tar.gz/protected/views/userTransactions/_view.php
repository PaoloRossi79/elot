<?php
/* @var $this UserTransactionsController */
/* @var $data UserTransactions */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->id), array('view', 'id'=>$data->id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('user_id')); ?>:</b>
	<?php echo CHtml::encode($data->user_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('transaction_type')); ?>:</b>
	<?php echo CHtml::encode($data->transaction_type); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('transaction_ref_id')); ?>:</b>
	<?php echo CHtml::encode($data->transaction_ref_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('value')); ?>:</b>
	<?php echo CHtml::encode($data->value); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('is_confirmed')); ?>:</b>
	<?php echo CHtml::encode($data->is_confirmed); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('promotion_id')); ?>:</b>
	<?php echo CHtml::encode($data->promotion_id); ?>
	<br />

	<?php /*
	<b><?php echo CHtml::encode($data->getAttributeLabel('created')); ?>:</b>
	<?php echo CHtml::encode($data->created); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('modified')); ?>:</b>
	<?php echo CHtml::encode($data->modified); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('last_modified_by')); ?>:</b>
	<?php echo CHtml::encode($data->last_modified_by); ?>
	<br />

	*/ ?>

</div>