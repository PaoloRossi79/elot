Version 1.2.2
=============

- You should change yii alias for HOAuthWidget from `ext.hoauth.HOAuthWidget` to `ext.hoauth.widgets.HOAuth`
