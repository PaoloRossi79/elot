<?php /* @var $this Controller */ ?>
<?php $this->beginContent('//layouts/main'); ?>
<div class="row">
  <div class="col-md-4 col-md-offset-3">
      <?php echo $content; ?>
  </div>
</div>
<?php $this->endContent(); ?>